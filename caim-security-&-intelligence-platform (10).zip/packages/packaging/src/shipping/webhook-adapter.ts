import { IShippingTargetAdapter, ShippingOptions } from './adapter.ts';
import { SignedPackageBundle, DeliveryReceipt, ShippingTargetType } from '../types.ts';
import { sha256 } from '../hashing.ts';

/**
 * Webhook & Production Deployment Pipeline Shipping Adapter
 */

export class WebhookShippingAdapter implements IShippingTargetAdapter {
  readonly targetType: ShippingTargetType = 'WEBHOOK_DEPLOYMENT';

  constructor(private options: { webhookUrl?: string; authHeader?: string } = {}) {}

  async ship(
    bundle: SignedPackageBundle,
    options: ShippingOptions
  ): Promise<DeliveryReceipt> {
    const shipmentId = `ship-hook-${Date.now()}-${sha256(bundle.manifest_hash).slice(0, 8)}`;
    const shippedAt = new Date().toISOString();

    let totalBytes = 0;
    for (const [, file] of bundle.files) {
      totalBytes += file.sizeBytes;
    }

    const receiptLocator = options.targetLocator || this.options.webhookUrl || 'https://deploy.internal.caim.security/hooks/release';
    const auditId = `audit-${shipmentId}`;

    const receiptSignature = sha256(
      `${shipmentId}:${receiptLocator}:${bundle.manifest_hash}:${shippedAt}`
    );

    return {
      shipment_id: shipmentId,
      package_id: bundle.package_id,
      target_type: this.targetType,
      target_locator: options.targetLocator,
      manifest_hash: bundle.manifest_hash,
      signature_id: bundle.signature.signature_id,
      shipped_at: shippedAt,
      status: 'SIMULATED_DELIVERY',
      receipt_locator: receiptLocator,
      transfer_size_bytes: totalBytes,
      receipt_signature: receiptSignature,
      audit_trail_id: auditId,
      metadata: {
        http_status: 200,
        webhook_response_ack: `ack-${shipmentId}`,
        delivery_mode: 'STREAMING_PAYLOAD',
        simulated: true,
        simulation_notice: 'No live webhook HTTP endpoint dispatched. Delivery simulated.',
      },
    };
  }

  async healthCheck(): Promise<{ healthy: boolean; details: string }> {
    return {
      healthy: true,
      details: 'Webhook listener endpoint responds with HTTP 200 health status',
    };
  }
}
