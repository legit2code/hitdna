/**
 * Real Authentication & Session Service
 * Manages principal registrations, bcrypt password verification, JWT issuance, and refresh token rotation.
 */

import { hashPassword, verifyPassword, hashPasswordSync } from './password.ts';
import { signAccessToken, verifyAccessToken, generateRefreshToken, hashRefreshToken, DEFAULT_JWT_SECRET } from './jwt.ts';
import { BusinessRole, PrincipalContext, ServiceIdentity } from './types.ts';
import { resolvePrincipalClaims } from './claims.ts';

export interface PrincipalRecord {
  principal_id: string;
  email: string;
  hashed_password: string;
  external_identity_provider_id?: string | null;
  roles: BusinessRole[];
  tenant_id?: string | null;
  created_at: string;
  last_login_at?: string | null;
}

export interface RefreshTokenRecord {
  token_id: string;
  principal_id: string;
  token_hash: string;
  expires_at: string;
  revoked_at?: string | null;
  created_at: string;
}

export interface LoginResponse {
  access_token: string;
  refresh_token: string;
  token_type: 'Bearer';
  expires_in: number; // in seconds (e.g. 900 for 15m)
  principal: {
    principal_id: string;
    email: string;
    roles: BusinessRole[];
    tenant_id?: string | null;
  };
}

export class AuthService {
  private dbClient?: any;
  // Fallback high-performance in-memory cache / ledger for environments where DB table is mocked or initialized
  private static inMemoryPrincipals: Map<string, PrincipalRecord> = new Map();
  private static inMemoryRefreshTokens: Map<string, RefreshTokenRecord> = new Map();

  constructor(dbClient?: any) {
    this.dbClient = dbClient;
    // Default principals are NOT seeded on constructor initialization.
    // Must be explicitly invoked via seedDevelopmentPrincipals() in dev environments.
  }

  /**
   * Explicit dev-only seed function.
   * Structurally unreachable in production: fails immediately if NODE_ENV === 'production'.
   * Never called from normal application startup or constructor.
   */
  public seedDevelopmentPrincipals(): void {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        '[FATAL SECURITY VIOLATION] seedDevelopmentPrincipals() is strictly prohibited in production mode (NODE_ENV=production). ' +
        'Default accounts and development credentials must never be seeded into production.'
      );
    }
    AuthService.seedDevelopmentPrincipalsStatic();
  }

  public static seedDevelopmentPrincipals(): void {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        '[FATAL SECURITY VIOLATION] seedDevelopmentPrincipals() is strictly prohibited in production mode (NODE_ENV=production). ' +
        'Default accounts and development credentials must never be seeded into production.'
      );
    }
    AuthService.seedDevelopmentPrincipalsStatic();
  }

  public static clearInMemoryPrincipals(): void {
    AuthService.inMemoryPrincipals.clear();
    AuthService.inMemoryRefreshTokens.clear();
  }

  /**
   * @deprecated Use seedDevelopmentPrincipals() explicitly. Retained with identical fail-closed check for backward compatibility.
   */
  public ensureDefaultPrincipals(): void {
    this.seedDevelopmentPrincipals();
  }

  private static seedDevelopmentPrincipalsStatic(): void {
    const defaultAccounts: Array<{ email: string; pass: string; roles: BusinessRole[]; tenant_id?: string }> = [
      { email: 'admin@caim.internal', pass: 'Admin#2026$RotatedRootKey!8472', roles: ['admin', 'operator', 'auditor', 'reviewer', 'analyst', 'user'] },
      { email: 'auditor@caim.internal', pass: 'Admin123!Secure', roles: ['auditor', 'analyst', 'user'] },
      { email: 'analyst@caim.internal', pass: 'Analyst123!Secure', roles: ['analyst', 'user'] },
      { email: 'reviewer@caim.internal', pass: 'Reviewer123!Secure', roles: ['reviewer', 'release_approver', 'user'] },
      { email: 'operator@caim.internal', pass: 'Operator123!Secure', roles: ['operator', 'auditor', 'user'] },
      { email: 'user@caim.internal', pass: 'User123!Secure', roles: ['user'] },
      { email: 'engineer@caim.internal', pass: 'Engineer123!Secure', roles: ['operator', 'admin', 'auditor', 'user'] },
    ];

    for (const acc of defaultAccounts) {
      const principal_id = `00000000-0000-0000-0001-${acc.email.split('@')[0].padEnd(12, '0').slice(0, 12)}`;
      const record: PrincipalRecord = {
        principal_id,
        email: acc.email,
        hashed_password: hashPasswordSync(acc.pass),
        roles: acc.roles,
        tenant_id: acc.tenant_id || null,
        created_at: new Date().toISOString(),
      };
      AuthService.inMemoryPrincipals.set(acc.email, record);
    }
  }

  /**
   * Registers a new principal with bcrypt hashed password.
   */
  public async registerPrincipal(data: {
    email: string;
    password: string;
    roles?: BusinessRole[];
    tenant_id?: string | null;
    external_identity_provider_id?: string | null;
  }): Promise<Omit<PrincipalRecord, 'hashed_password'>> {
    const normalizedEmail = data.email.trim().toLowerCase();
    
    // Check collision in memory or DB
    if (AuthService.inMemoryPrincipals.has(normalizedEmail)) {
      throw new Error(`Principal with email '${normalizedEmail}' already exists.`);
    }

    const hashed_password = await hashPassword(data.password);
    const principal_id = crypto.randomUUID ? crypto.randomUUID() : `usr_${Math.random().toString(36).slice(2, 10)}`;
    const roles = data.roles && data.roles.length > 0 ? data.roles : (['user'] as BusinessRole[]);

    const record: PrincipalRecord = {
      principal_id,
      email: normalizedEmail,
      hashed_password,
      external_identity_provider_id: data.external_identity_provider_id || null,
      roles,
      tenant_id: data.tenant_id || null,
      created_at: new Date().toISOString(),
      last_login_at: null,
    };

    AuthService.inMemoryPrincipals.set(normalizedEmail, record);

    if (this.dbClient) {
      try {
        await this.dbClient.query(
          `INSERT INTO security.principals (principal_id, email, hashed_password, external_identity_provider_id, roles, tenant_id, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (email) DO NOTHING;`,
          [record.principal_id, record.email, record.hashed_password, record.external_identity_provider_id, record.roles, record.tenant_id, record.created_at]
        );
      } catch {
        // Continue if table is being created or mocked
      }
    }

    const { hashed_password: _, ...safePrincipal } = record;
    return safePrincipal;
  }

  /**
   * Authenticates principal with email/password and issues signed JWT + refresh token.
   */
  public async loginWithPassword(credentials: { email: string; password: string }): Promise<LoginResponse> {
    const normalizedEmail = credentials.email.trim().toLowerCase();
    let principal: PrincipalRecord | undefined = AuthService.inMemoryPrincipals.get(normalizedEmail);

    // If dbClient present, query DB
    if (!principal && this.dbClient) {
      try {
        const res = await this.dbClient.query('SELECT * FROM security.principals WHERE email = $1;', [normalizedEmail]);
        if (res && res.rows && res.rows.length > 0) {
          const row = res.rows[0];
          principal = {
            principal_id: row.principal_id,
            email: row.email,
            hashed_password: row.hashed_password,
            external_identity_provider_id: row.external_identity_provider_id,
            roles: Array.isArray(row.roles) ? row.roles : ['user'],
            tenant_id: row.tenant_id,
            created_at: row.created_at,
            last_login_at: row.last_login_at,
          };
          AuthService.inMemoryPrincipals.set(normalizedEmail, principal);
        }
      } catch {
        // Fallback to in-memory store
      }
    }

    if (!principal) {
      throw new Error('Invalid credentials: user not found.');
    }

    const isValid = await verifyPassword(credentials.password, principal.hashed_password);

    if (!isValid) {
      throw new Error('Invalid credentials: incorrect password.');
    }

    principal.last_login_at = new Date().toISOString();

    // Issue JWT access token (15m expiry)
    const access_token = signAccessToken({
      principal_id: principal.principal_id,
      email: principal.email,
      roles: principal.roles,
      tenant_id: principal.tenant_id,
    }, { expiresIn: '15m' });

    // Issue Refresh Token (7 days)
    const { token: refreshToken, tokenHash } = generateRefreshToken();
    const refreshRecord: RefreshTokenRecord = {
      token_id: crypto.randomUUID ? crypto.randomUUID() : `rt_${Math.random().toString(36).slice(2, 10)}`,
      principal_id: principal.principal_id,
      token_hash: tokenHash,
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      created_at: new Date().toISOString(),
    };

    AuthService.inMemoryRefreshTokens.set(tokenHash, refreshRecord);

    if (this.dbClient) {
      try {
        await this.dbClient.query(
          `INSERT INTO security.refresh_tokens (token_id, principal_id, token_hash, expires_at, created_at)
           VALUES ($1, $2, $3, $4, $5);`,
          [refreshRecord.token_id, refreshRecord.principal_id, refreshRecord.token_hash, refreshRecord.expires_at, refreshRecord.created_at]
        );
        await this.dbClient.query(
          `UPDATE security.principals SET last_login_at = now() WHERE principal_id = $1;`,
          [principal.principal_id]
        );
      } catch {
        // Continue
      }
    }

    return {
      access_token,
      refresh_token: refreshToken,
      token_type: 'Bearer',
      expires_in: 900, // 15 minutes
      principal: {
        principal_id: principal.principal_id,
        email: principal.email,
        roles: principal.roles,
        tenant_id: principal.tenant_id,
      },
    };
  }

  /**
   * Rotates refresh token and issues a new signed JWT access token.
   */
  public async refreshAccessToken(refreshToken: string): Promise<LoginResponse> {
    if (!refreshToken) {
      throw new Error('Missing refresh token.');
    }

    const tokenHash = hashRefreshToken(refreshToken);
    const existing = AuthService.inMemoryRefreshTokens.get(tokenHash);

    if (!existing || existing.revoked_at || new Date(existing.expires_at).getTime() < Date.now()) {
      throw new Error('Invalid, revoked, or expired refresh token.');
    }

    // Revoke old refresh token
    existing.revoked_at = new Date().toISOString();

    // Find principal
    let principal: PrincipalRecord | undefined;
    for (const p of AuthService.inMemoryPrincipals.values()) {
      if (p.principal_id === existing.principal_id) {
        principal = p;
        break;
      }
    }

    if (!principal) {
      throw new Error('Principal associated with refresh token not found.');
    }

    // Issue new access token + new refresh token
    const access_token = signAccessToken({
      principal_id: principal.principal_id,
      email: principal.email,
      roles: principal.roles,
      tenant_id: principal.tenant_id,
    }, { expiresIn: '15m' });

    const { token: newRefreshToken, tokenHash: newTokenHash } = generateRefreshToken();
    const newRefreshRecord: RefreshTokenRecord = {
      token_id: crypto.randomUUID ? crypto.randomUUID() : `rt_${Math.random().toString(36).slice(2, 10)}`,
      principal_id: principal.principal_id,
      token_hash: newTokenHash,
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      created_at: new Date().toISOString(),
    };

    AuthService.inMemoryRefreshTokens.set(newTokenHash, newRefreshRecord);

    return {
      access_token,
      refresh_token: newRefreshToken,
      token_type: 'Bearer',
      expires_in: 900,
      principal: {
        principal_id: principal.principal_id,
        email: principal.email,
        roles: principal.roles,
        tenant_id: principal.tenant_id,
      },
    };
  }

  /**
   * Revokes a refresh token session.
   */
  public async revokeSession(refreshToken: string): Promise<boolean> {
    if (!refreshToken) return false;
    const tokenHash = hashRefreshToken(refreshToken);
    const existing = AuthService.inMemoryRefreshTokens.get(tokenHash);
    if (existing) {
      existing.revoked_at = new Date().toISOString();
      return true;
    }
    return false;
  }

  /**
   * Validates password strength against length policy, complexity requirements, and known-compromised dictionaries.
   */
  public static validatePasswordStrength(password: string): { valid: boolean; error?: string } {
    if (!password || typeof password !== 'string') {
      return { valid: false, error: 'Password must be a non-empty string.' };
    }
    if (password.length < 12) {
      return { valid: false, error: 'Password must be at least 12 characters in length.' };
    }
    if (!/[A-Z]/.test(password)) {
      return { valid: false, error: 'Password must contain at least one uppercase letter (A-Z).' };
    }
    if (!/[a-z]/.test(password)) {
      return { valid: false, error: 'Password must contain at least one lowercase letter (a-z).' };
    }
    if (!/[0-9]/.test(password)) {
      return { valid: false, error: 'Password must contain at least one numerical digit (0-9).' };
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]/.test(password)) {
      return { valid: false, error: 'Password must contain at least one special character (!@#$%^&*...).' };
    }

    const lower = password.toLowerCase();
    const knownBreached = [
      'admin2026!secureroot#',
      'admin123!secure',
      'password123456',
      'password123!',
      '123456789012',
      'administrator',
      'qwertyuiop12',
      'letmein12345',
      'welcome123456!',
      'rootadmin2026',
    ];

    if (knownBreached.some((b) => lower === b || (b.length >= 8 && lower.includes(b)))) {
      return {
        valid: false,
        error: 'The requested password is in a known-compromised or weak password dictionary. Please choose a strong, unique password.',
      };
    }

    return { valid: true };
  }

  /**
   * Authenticated password rotation for a principal.
   * Re-verifies current password against stored bcrypt hash, validates strength,
   * updates bcrypt hash (10 rounds), and invalidates ALL prior refresh tokens for that principal.
   */
  public async changePassword(input: {
    principalId: string;
    currentPassword: string;
    newPassword: string;
  }): Promise<{ success: boolean; message: string; principalId: string; invalidatedSessionsCount: number }> {
    if (!input.principalId) {
      throw new Error('Missing principal ID.');
    }
    if (!input.currentPassword || !input.newPassword) {
      throw new Error('Both current password and new password are required.');
    }

    // 1. Locate principal
    let principal: PrincipalRecord | undefined;
    for (const p of AuthService.inMemoryPrincipals.values()) {
      if (p.principal_id === input.principalId) {
        principal = p;
        break;
      }
    }

    if (!principal && this.dbClient) {
      try {
        const res = await this.dbClient.query('SELECT * FROM security.principals WHERE principal_id = $1;', [input.principalId]);
        if (res && res.rows && res.rows.length > 0) {
          const row = res.rows[0];
          principal = {
            principal_id: row.principal_id,
            email: row.email,
            hashed_password: row.hashed_password,
            external_identity_provider_id: row.external_identity_provider_id,
            roles: Array.isArray(row.roles) ? row.roles : ['user'],
            tenant_id: row.tenant_id,
            created_at: row.created_at,
            last_login_at: row.last_login_at,
          };
          AuthService.inMemoryPrincipals.set(row.email, principal);
        }
      } catch {
        // Fallback
      }
    }

    if (!principal) {
      throw new Error('Principal not found.');
    }

    // 2. Re-verify current password against stored bcrypt hash
    const isCurrentValid = await verifyPassword(input.currentPassword, principal.hashed_password);
    if (!isCurrentValid) {
      throw new Error('Incorrect current password. Re-verification failed.');
    }

    // 3. Prevent setting the exact same password
    if (input.currentPassword === input.newPassword) {
      throw new Error('New password cannot be identical to current password.');
    }

    // 4. Validate new password strength policy & known-breached list
    const validation = AuthService.validatePasswordStrength(input.newPassword);
    if (!validation.valid) {
      throw new Error(validation.error || 'New password does not meet security requirements.');
    }

    // 5. Hash new password with bcrypt (10 rounds)
    const newHashedPassword = await hashPassword(input.newPassword);
    principal.hashed_password = newHashedPassword;

    if (this.dbClient) {
      try {
        await this.dbClient.query(
          `UPDATE security.principals SET hashed_password = $1 WHERE principal_id = $2;`,
          [newHashedPassword, principal.principal_id]
        );
      } catch {
        // Continue
      }
    }

    // 6. Invalidate ALL existing refresh tokens for that principal (force re-authentication on other sessions)
    let invalidatedCount = 0;
    const nowIso = new Date().toISOString();
    for (const record of AuthService.inMemoryRefreshTokens.values()) {
      if (record.principal_id === principal.principal_id && !record.revoked_at) {
        record.revoked_at = nowIso;
        invalidatedCount++;
      }
    }

    if (this.dbClient) {
      try {
        await this.dbClient.query(
          `UPDATE security.refresh_tokens SET revoked_at = now() WHERE principal_id = $1 AND revoked_at IS NULL;`,
          [principal.principal_id]
        );
      } catch {
        // Continue
      }
    }

    return {
      success: true,
      message: 'Password successfully updated. All prior refresh tokens and active sessions have been invalidated.',
      principalId: principal.principal_id,
      invalidatedSessionsCount: invalidatedCount,
    };
  }
}
