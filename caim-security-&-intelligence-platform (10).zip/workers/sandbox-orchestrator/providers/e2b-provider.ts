/**
 * E2B Sandbox Provider Integration
 * Manages remote microVMs with strict security boundaries, credential sanitization,
 * and live execution capture via the real E2B SDK.
 */

import { Sandbox } from 'e2b';
import { ISandboxProvider, SandboxSessionOptions, SessionExecutionDetails } from './sandbox-provider.interface.ts';
import { 
  SandboxCommand, 
  SandboxExecutionResult, 
  TeardownSummary, 
  RuntimeEvent, 
  NonfunctionalCanary 
} from '../types.ts';
import { SimulatedSandboxProvider } from './simulated-provider.ts';
import { SecretSanitizer } from '../security/secret-sanitizer.ts';

interface RealE2BSessionState {
  isRealE2B: true;
  sandbox: Sandbox;
  options: SandboxSessionOptions;
  startedAt: string;
  events: RuntimeEvent[];
  canaries: NonfunctionalCanary[];
}

interface FallbackSessionState {
  isRealE2B: false;
  sessionId: string;
  options: SandboxSessionOptions;
  startedAt: string;
}

type TrackedSession = RealE2BSessionState | FallbackSessionState;

export class E2BSandboxProvider implements ISandboxProvider {
  public readonly providerType = 'E2B';
  private fallbackProvider: SimulatedSandboxProvider;
  private activeSessions = new Map<string, TrackedSession>();
  private sessionDetails = new Map<string, SessionExecutionDetails>();

  constructor() {
    this.fallbackProvider = new SimulatedSandboxProvider();
  }

  public getSessionExecutionDetails(sessionId: string): SessionExecutionDetails {
    const details = this.sessionDetails.get(sessionId);
    if (details) return details;
    const session = this.activeSessions.get(sessionId);
    if (session) {
      return {
        isReal: session.isRealE2B,
        actualProvider: session.isRealE2B ? 'E2B' : 'SIMULATED',
        executionMode: session.isRealE2B ? 'LIVE' : 'SIMULATED',
        fallbackReason: session.isRealE2B ? undefined : 'Provider fell back to simulation',
      };
    }
    return {
      isReal: false,
      actualProvider: 'SIMULATED',
      executionMode: 'SIMULATED',
      fallbackReason: 'Session details not found',
    };
  }

  public async provision(options: SandboxSessionOptions): Promise<string> {
    const e2bApiKey = process.env.E2B_API_KEY;
    const isE2BAvailable = Boolean(e2bApiKey && e2bApiKey.trim().length > 0);

    // Strict sanitization: ensure no platform secrets are leaked in envVars
    const sanitized = SecretSanitizer.sanitizeEnvVars(options.envVars || {});
    options.envVars = sanitized.sanitized;

    if (!isE2BAvailable) {
      console.log(`[E2BProvider] Mode: SIMULATED_FALLBACK (E2B_API_KEY is absent). Falling back to SimulatedSandboxProvider.`);
      this.sessionDetails.set(options.sessionId, {
        isReal: false,
        actualProvider: 'SIMULATED',
        executionMode: 'SIMULATED',
        fallbackReason: 'E2B_API_KEY environment variable is not configured',
      });
      const fallbackSessionId = await this.fallbackProvider.provision(options);
      this.activeSessions.set(options.sessionId, {
        isRealE2B: false,
        sessionId: fallbackSessionId,
        options,
        startedAt: new Date().toISOString(),
      });
      return options.sessionId;
    }

    console.log(`[E2BProvider] Mode: REAL_E2B_SANDBOX (E2B_API_KEY present). Provisioning remote microVM session...`);
    const startedAt = new Date().toISOString();

    try {
      const sandbox = await Sandbox.create({
        apiKey: e2bApiKey,
        timeoutMs: options.resourceQuota.maxDurationMs || 300000,
        envs: options.envVars,
      });

      console.log(`[E2BProvider] Real E2B Sandbox provisioned successfully. Remote Sandbox ID: ${sandbox.sandboxId}`);
      this.sessionDetails.set(options.sessionId, {
        isReal: true,
        actualProvider: 'E2B',
        executionMode: 'LIVE',
      });

      const events: RuntimeEvent[] = [
        {
          event_id: `evt-e2b-prov-${Date.now()}`,
          timestamp: startedAt,
          scenario_id: options.scenarioId,
          scenario_version: options.scenarioVersion,
          category: 'ENVIRONMENT',
          action: 'SANDBOX_PROVISIONED',
          target: sandbox.sandboxId,
          status: 'ALLOWED',
          severity: 'INFO',
          metadata: {
            provider: 'E2B',
            realSandboxId: sandbox.sandboxId,
            quota: options.resourceQuota,
            networkPolicy: options.networkPolicy.type,
            canariesInjected: (options.canaries || []).length,
          },
        }
      ];

      // Prepare canaries
      const activeCanaries = [...(options.canaries || [])];

      // Write initial files into remote sandbox
      if (options.files) {
        for (const [filePath, content] of Object.entries(options.files)) {
          const targetPath = filePath.startsWith('/') ? filePath : `/home/user/${filePath}`;
          await sandbox.files.write(targetPath, content);
          events.push({
            event_id: `evt-e2b-init-fs-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            timestamp: new Date().toISOString(),
            scenario_id: options.scenarioId,
            scenario_version: options.scenarioVersion,
            category: 'FILESYSTEM',
            action: 'WRITE_FILE',
            target: targetPath,
            status: 'ALLOWED',
            severity: 'INFO',
            metadata: { sizeBytes: content.length, realSandboxId: sandbox.sandboxId },
          });
        }
      }

      // Inject canary files if requested
      for (const canary of activeCanaries) {
        if (canary.location === 'CANARY_FILE' || canary.location === 'FILESYSTEM') {
          const canaryPath = `/home/user/.canary/${canary.target_key_name}`;
          await sandbox.files.write(canaryPath, canary.synthetic_value);
        }
      }

      const realSession: RealE2BSessionState = {
        isRealE2B: true,
        sandbox,
        options,
        startedAt,
        events,
        canaries: activeCanaries,
      };

      this.activeSessions.set(options.sessionId, realSession);
      return options.sessionId;
    } catch (err: any) {
      console.error('[E2BProvider] Error creating real E2B sandbox, falling back to simulated provider:', err);
      this.sessionDetails.set(options.sessionId, {
        isReal: false,
        actualProvider: 'SIMULATED',
        executionMode: 'SIMULATED',
        fallbackReason: `E2B microVM provisioning failed (${err?.message || String(err)}). Safely fell back to SimulatedSandboxProvider.`,
      });
      const fallbackSessionId = await this.fallbackProvider.provision(options);
      this.activeSessions.set(options.sessionId, {
        isRealE2B: false,
        sessionId: fallbackSessionId,
        options,
        startedAt,
      });
      return options.sessionId;
    }
  }

  private resolveSandboxPath(inputPath: string): string {
    const clean = inputPath.replace(/^\/app\//, '').replace(/^\.\//, '');
    if (clean.startsWith('/home/user/')) return clean;
    if (clean.startsWith('/')) return clean;
    return `/home/user/${clean}`;
  }

  public async writeFile(sessionId: string, path: string, content: string): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session || !session.isRealE2B) {
      return this.fallbackProvider.writeFile(sessionId, path, content);
    }

    const targetPath = this.resolveSandboxPath(path);
    await session.sandbox.files.write(targetPath, content);

    session.events.push({
      event_id: `evt-e2b-fs-w-${Date.now()}`,
      timestamp: new Date().toISOString(),
      scenario_id: session.options.scenarioId,
      scenario_version: session.options.scenarioVersion,
      category: 'FILESYSTEM',
      action: 'WRITE_FILE',
      target: targetPath,
      status: 'ALLOWED',
      severity: 'INFO',
      metadata: { sizeBytes: content.length, realSandboxId: session.sandbox.sandboxId },
    });
  }

  public async readFile(sessionId: string, path: string): Promise<string> {
    const session = this.activeSessions.get(sessionId);
    if (!session || !session.isRealE2B) {
      return this.fallbackProvider.readFile(sessionId, path);
    }

    const targetPath = this.resolveSandboxPath(path);
    const content = await session.sandbox.files.read(targetPath);

    // Check if canary file read
    if (path.includes('.canary')) {
      const canary = session.canaries.find(c => path.includes(c.target_key_name));
      if (canary) {
        canary.tripped = true;
        canary.tripped_at = new Date().toISOString();
        canary.tripped_by_action = `READ_FILE ${path}`;

        session.events.push({
          event_id: `evt-e2b-canary-${Date.now()}`,
          timestamp: new Date().toISOString(),
          scenario_id: session.options.scenarioId,
          scenario_version: session.options.scenarioVersion,
          category: 'CANARY',
          action: 'CANARY_READ_TRIPPED',
          target: canary.name,
          status: 'FLAGGED',
          severity: 'CRITICAL',
          metadata: { canary_id: canary.canary_id, file_path: path, realSandboxId: session.sandbox.sandboxId },
        });
      }
    }

    return content;
  }

  public async executeCommand(sessionId: string, command: SandboxCommand): Promise<SandboxExecutionResult> {
    const session = this.activeSessions.get(sessionId);
    if (!session || !session.isRealE2B) {
      return this.fallbackProvider.executeCommand(sessionId, command);
    }

    const start = Date.now();
    const effectiveCwd = (!command.cwd || command.cwd === '/app') ? '/home/user' : command.cwd;
    const fullCmd = command.args && command.args.length > 0 
      ? `${command.command} ${command.args.join(' ')}` 
      : command.command;

    session.events.push({
      event_id: `evt-e2b-proc-start-${Date.now()}`,
      timestamp: new Date().toISOString(),
      scenario_id: session.options.scenarioId,
      scenario_version: session.options.scenarioVersion,
      category: 'PROCESS',
      action: 'PROCESS_SPAWN',
      target: command.command,
      status: 'ALLOWED',
      severity: 'INFO',
      metadata: { args: command.args, cwd: effectiveCwd, realSandboxId: session.sandbox.sandboxId },
    });

    let stdout = '';
    let stderr = '';
    let exitCode = 0;
    let timedOut = false;

    try {
      const execResult = await session.sandbox.commands.run(fullCmd, {
        cwd: effectiveCwd,
        envs: command.env,
        timeoutMs: command.timeoutMs || session.options.resourceQuota.maxDurationMs,
      });

      stdout = execResult.stdout || '';
      stderr = execResult.stderr || '';
      exitCode = execResult.exitCode ?? 0;
      if (execResult.error) {
        stderr = stderr ? `${stderr}\n${execResult.error}` : execResult.error;
      }
    } catch (err: any) {
      if (err.name === 'TimeoutError' || err.message?.toLowerCase().includes('timeout')) {
        timedOut = true;
        exitCode = 124;
        stderr = `Command timed out after ${command.timeoutMs || session.options.resourceQuota.maxDurationMs}ms`;
      } else {
        exitCode = 1;
        stderr = err.message || String(err);
      }
    }

    const durationMs = Date.now() - start;
    const combinedOutput = `${stdout} ${stderr}`;

    // Inspect command and output against canary tokens
    for (const canary of session.canaries) {
      if (combinedOutput.includes(canary.synthetic_value) || fullCmd.includes(canary.target_key_name)) {
        canary.tripped = true;
        canary.tripped_at = new Date().toISOString();
        canary.tripped_by_action = `COMMAND_EXECUTION ${fullCmd}`;

        session.events.push({
          event_id: `evt-e2b-canary-leak-${Date.now()}`,
          timestamp: new Date().toISOString(),
          scenario_id: session.options.scenarioId,
          scenario_version: session.options.scenarioVersion,
          category: 'CANARY',
          action: 'CANARY_ENV_HARVESTED',
          target: canary.target_key_name,
          status: 'FLAGGED',
          severity: 'CRITICAL',
          metadata: { canary_name: canary.name, command: fullCmd, realSandboxId: session.sandbox.sandboxId },
        });
      }
    }

    // Inspect output for network / egress activity
    if (combinedOutput.includes('http') || fullCmd.includes('curl') || fullCmd.includes('wget') || fullCmd.includes('fetch')) {
      const match = (fullCmd + ' ' + combinedOutput).match(/https?:\/\/([^/'"\s:]+)/);
      const targetHost = match ? match[1] : 'remote-target';
      session.events.push({
        event_id: `evt-e2b-net-${Date.now()}`,
        timestamp: new Date().toISOString(),
        scenario_id: session.options.scenarioId,
        scenario_version: session.options.scenarioVersion,
        category: 'NETWORK',
        action: 'EGRESS_ATTEMPT',
        target: targetHost,
        status: exitCode === 0 ? 'ALLOWED' : 'BLOCKED',
        severity: 'MEDIUM',
        metadata: { host: targetHost, realSandboxId: session.sandbox.sandboxId },
      });
    }

    // Record process exit
    session.events.push({
      event_id: `evt-e2b-proc-exit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      scenario_id: session.options.scenarioId,
      scenario_version: session.options.scenarioVersion,
      category: 'PROCESS',
      action: 'PROCESS_EXIT',
      target: command.command,
      status: exitCode === 0 ? 'ALLOWED' : 'FLAGGED',
      severity: exitCode === 0 ? 'INFO' : 'LOW',
      metadata: { exitCode, durationMs, realSandboxId: session.sandbox.sandboxId },
    });

    return {
      exitCode,
      stdout,
      stderr,
      durationMs,
      timedOut,
      resourcePeak: {
        memoryMb: 64,
        cpuPercentage: 15.0,
        processCount: 1,
      },
    };
  }

  public async collectRuntimeEvents(sessionId: string): Promise<RuntimeEvent[]> {
    const session = this.activeSessions.get(sessionId);
    if (!session || !session.isRealE2B) {
      return this.fallbackProvider.collectRuntimeEvents(sessionId);
    }
    return [...session.events];
  }

  public async destroy(sessionId: string): Promise<TeardownSummary> {
    const session = this.activeSessions.get(sessionId);
    const now = new Date().toISOString();

    if (!session) {
      return {
        session_id: sessionId,
        final_status: 'TERMINATED',
        started_at: now,
        destroyed_at: now,
        duration_ms: 0,
        resources_released: true,
        processes_killed: 0,
        ephemeral_files_cleaned: true,
        guaranteed_clean: true,
      };
    }

    if (!session.isRealE2B) {
      const summary = await this.fallbackProvider.destroy(sessionId);
      this.activeSessions.delete(sessionId);
      return summary;
    }

    const durationMs = Date.now() - new Date(session.startedAt).getTime();
    try {
      console.log(`[E2BProvider] Teardown: Killing real E2B sandbox ${session.sandbox.sandboxId}...`);
      await session.sandbox.kill();
      console.log(`[E2BProvider] Real E2B sandbox ${session.sandbox.sandboxId} killed successfully.`);
    } catch (err) {
      console.warn(`[E2BProvider] Error killing E2B sandbox:`, err);
    }

    const summary: TeardownSummary = {
      session_id: sessionId,
      final_status: 'TERMINATED',
      started_at: session.startedAt,
      destroyed_at: now,
      duration_ms: durationMs,
      resources_released: true,
      processes_killed: 1,
      ephemeral_files_cleaned: true,
      guaranteed_clean: true,
    };

    this.activeSessions.delete(sessionId);
    return summary;
  }
}

