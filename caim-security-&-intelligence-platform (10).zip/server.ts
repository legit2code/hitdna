import './apps/server/index.ts';
